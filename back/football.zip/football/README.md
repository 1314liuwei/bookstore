Execute command as

```
./minileague.sh top4.dat score1 score2
```

The format may be different. This is related to the computer configuration. The answer is no problem